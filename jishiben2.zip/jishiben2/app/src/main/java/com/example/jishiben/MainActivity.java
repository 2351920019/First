package com.example.jishiben;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import database.UserDBHelper;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText on_user, on_password;
    private RadioGroup on_juese;
    private Button btn1 = null;
    private Button btn2 = null;
    String juese;
    private String mDatabaseName;
    private UserDBHelper mHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        on_user = findViewById(R.id.on_user);
        on_password = findViewById(R.id.on_password);
        on_juese = findViewById(R.id.on_juese);

        //shujuku
        //shujukulujingshengcheng
        mDatabaseName = getFilesDir()+"/test.db";
        SQLiteDatabase db=openOrCreateDatabase(mDatabaseName, Context.MODE_PRIVATE,null);

        mHelper = UserDBHelper.getInstance(this);
        mHelper.openReadLink();
        mHelper.openWriteLink();

        //shujuku



        on_juese.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.student) juese = "student";
                if (i == R.id.teacher) juese = "teacher";
            }
        });

        btn1 = findViewById(R.id.haveoning);
        btn1.setOnClickListener(this);

        btn2 = findViewById(R.id.oning);
        btn2.setOnClickListener(this);



    }






    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.oning:
                if(juese.equals("student")&&!mHelper.oning_query(on_user.getText().toString(),on_password.getText().toString()).equals("-1")){
                Intent intent = new Intent(MainActivity.this, activity_gongneng.class);
                Bundle bundle=new Bundle();
                bundle.putString("oninguser",on_user.getText().toString());
                bundle.putInt("sql_connectday",mHelper.connect_day(on_user.getText().toString()));
                intent.putExtras(bundle);
                startActivity(intent);
                }

                else if(juese.equals("teacher")&&!mHelper.oning_query(on_user.getText().toString(),on_password.getText().toString()).equals("-1")){
                    Intent intent3 = new Intent(MainActivity.this, liulan.class);
                    startActivity(intent3);
                }else {
                    Toast.makeText(MainActivity.this, "用户名不存在或密码错误！", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.haveoning:
                Intent intent2 = new Intent(MainActivity.this, Zhuce.class);
                startActivity(intent2);
                break;
        }

    }
}