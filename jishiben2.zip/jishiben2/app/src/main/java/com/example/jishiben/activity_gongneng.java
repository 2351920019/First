package com.example.jishiben;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Date;

import database.UserDBHelper;

public class activity_gongneng extends AppCompatActivity implements View.OnClickListener {
    private EditText daykey,summary;
    private String id;
    private int day;
    private int keepdays=0,longestdays=0;
    private int remind=0;
    private UserDBHelper mHelper;
    private TextView day_receive;
    private TextView connectday_receive;
    private TextView longest_receive;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gongneng);

        daykey=findViewById(R.id.daykey);
        summary=findViewById(R.id.summary);

        SimpleDateFormat formatter= new SimpleDateFormat("MMdd");
        String daystring=formatter.format(new Date());
        day=Integer.valueOf(String.valueOf(daystring));

        //huoqushuju
        Bundle bundle=getIntent().getExtras();
        id=bundle.getString("oninguser");
        int connectday=bundle.getInt("sql_connectday");
        //huoqushuju

        setContentView(R.layout.activity_gongneng);
        day_receive = findViewById(R.id.receive_day);
        day_receive.setText("日期:"+day/100+"月"+day%100);

        connectday_receive = findViewById(R.id.receive_connectday);
        connectday_receive.setText("坚持天数:"+connectday%100+"天");

        longest_receive = findViewById(R.id.receive_longestday);
        longest_receive.setText("连续最长天数:"+connectday/100+"天");






        findViewById(R.id.daka).setOnClickListener(this);
        findViewById(R.id.naozhong).setOnClickListener(this);


    }



    @Override
    protected void onStart() {
        super.onStart();
        mHelper = UserDBHelper.getInstance(this);
        mHelper.openReadLink();
        mHelper.openWriteLink();
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.daka:
                if(mHelper.judge_daka(id,day)==1) {
                    if (mHelper.insert2(day, daykey.getText().toString(), summary.getText().toString(), keepdays, longestdays, id, remind) > 0) {
                        //longestday
                        keepdays = mHelper.connect_day(id);
                        longestdays = keepdays / 100;
                        keepdays = keepdays % 100;
                        //longestday
                        Toast.makeText(activity_gongneng.this, "添加成功！", Toast.LENGTH_SHORT).show();
                    }
                }else Toast.makeText(activity_gongneng.this, "不能重复打卡！", Toast.LENGTH_SHORT).show();


                break;


            case R.id.naozhong:
                Intent intent2 = new Intent(activity_gongneng.this, naozhong.class);
                startActivity(intent2);

                  break;

        }

    }
}