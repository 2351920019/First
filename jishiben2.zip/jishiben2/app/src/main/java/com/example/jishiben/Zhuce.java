package com.example.jishiben;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import database.UserDBHelper;


public class Zhuce extends AppCompatActivity implements View.OnClickListener {

    private EditText id,name,phonenumber,flat,password,aginpassword;
    private UserDBHelper mHelper;




    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zhuce2);


        id=findViewById(R.id.haveoning_id);
        name=findViewById(R.id.haveoning_name);
        phonenumber=findViewById(R.id.haveoning_phonenumber);
        flat=findViewById(R.id.haveoning_flat);
        password=findViewById(R.id.haveoning_password);
        aginpassword=findViewById(R.id.haveoning_aginpassword);
        findViewById(R.id.haveoning_submit).setOnClickListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mHelper = UserDBHelper.getInstance(this);
        mHelper.openReadLink();
        mHelper.openWriteLink();
    }


    @Override
    public void onClick(View view) {
        if(password.getText().toString().equals(aginpassword.getText().toString())){
            if(mHelper.insert(id.getText().toString(),name.getText().toString(),phonenumber.getText().toString(),flat.getText().toString(),password.getText().toString())>0)
                Toast.makeText(Zhuce.this, "添加成功！", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(Zhuce.this,"信息有误！",Toast.LENGTH_LONG).show();
        }
    }
}