package com.example.jishiben;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import database.UserDBHelper;

public class liulan extends AppCompatActivity implements View.OnClickListener {
    ListView listView=null;

    private TextView riqi,guanjianzi,zongjie,people;
    private  UserDBHelper mHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liulan);

        findViewById(R.id.liulanle).setOnClickListener(this);



    }

    @Override
    protected void onStart() {
        super.onStart();
        mHelper = UserDBHelper.getInstance(this);
        mHelper.openReadLink();
    }

    @Override
    public void onClick(View view) {
        mHelper.root_liulan();
        listView=findViewById(R.id.sqlliulan);
        Myadapt mb=new Myadapt();
        listView.setAdapter(mb);
        System.out.println(mHelper.judge);
    }

    private class Myadapt extends BaseAdapter {
        @Override
        public int getCount() {
            return mHelper.judge;
        }

        @Override
        public Object getItem(int i) {
            return mHelper.liulan2[i];
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            View view1=View.inflate(liulan.this,R.layout.mysqlliulan,null);
            riqi=view1.findViewById(R.id.receive_riqi);
            guanjianzi=view1.findViewById(R.id.receive_guanjianzi);
            zongjie=view1.findViewById(R.id.receive_zongjie);
            people=view1.findViewById(R.id.receive_people);

            riqi.setText("日期："+mHelper.liulan2[i]+"");
            guanjianzi.setText("关键字："+mHelper.liulan[i][0]);
            zongjie.setText("总结"+mHelper.liulan[i][1]);
            people.setText("学号:"+mHelper.liulan[i][2]);

            return view1;
        }
    }

}