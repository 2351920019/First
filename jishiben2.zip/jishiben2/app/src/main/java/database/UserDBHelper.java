package database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.DateTimeException;
import java.util.Currency;
import java.util.Date;

public class UserDBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME="test.db";
    private static final int DB_VERSION=1;
    private static UserDBHelper mHelper=null;
    private SQLiteDatabase mRDB=null;
    private SQLiteDatabase mWDB=null;

    public  String liulan[][]=new String[15][3];
    public  int liulan2[]=new int[15];
    public int judge;

    private UserDBHelper(Context context){
        super(context,DB_NAME,null,DB_VERSION);
    }

    public static UserDBHelper getInstance(Context context){
        if(mHelper==null){
            mHelper=new UserDBHelper(context);
        }
        return mHelper;
    }

    public SQLiteDatabase openReadLink(){
       if(mRDB==null||!mRDB.isOpen()){
           mRDB=mHelper.getReadableDatabase();
       }
       return mRDB;
    }

    public SQLiteDatabase openWriteLink(){
        if(mWDB==null||!mWDB.isOpen()){
            mWDB=mHelper.getWritableDatabase();
        }
        return mWDB;
    }

    public void closeLink(){
        if(mRDB!=null&&mRDB.isOpen()){
            mRDB.close();
            mRDB=null;
        }
        if(mWDB!=null&&mWDB.isOpen()){
            mWDB.close();
            mWDB=null;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql="create table users(id varchar(20)primary key,name varchar(20),phonenumber varchar(20),flat varchar(20),password varchar(20))";
        String sql2="create table storage(day int,daykey varchar(20),summary varchar(90),keepdays int,longestdays int,id varchar(20),remind int)";
        sqLiteDatabase.execSQL(sql);
        sqLiteDatabase.execSQL(sql2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public long insert(String id,String name,String phonenumber,String flat,String password){
        ContentValues values=new ContentValues();
        values.put("id",id);
        values.put("name",name);
        values.put("phonenumber",phonenumber);
        values.put("flat",flat);
        values.put("password",password);
       return mRDB.insert("users",null,values);

    }

    public long insert2(int day, String daykey, String summary, int keepdays, int longestdays, String id, int remind){
        ContentValues values=new ContentValues();

        values.put("day",day);
        values.put("daykey",daykey);
        values.put("summary",summary);
        values.put("keepdays",keepdays);
        values.put("longestdays",longestdays);
        values.put("id",id);
        values.put("remind",remind);
        return mRDB.insert("storage",null,values);
    }

    public String oning_query(String id,String password){
        Cursor cursor=mRDB.query("users",null,null,null,null,null,null);
        while(cursor.moveToNext()){
            String sqlid=cursor.getString(0);
            String sqlpassward=cursor.getString(4);
            if(sqlid.equals(id)&&sqlpassward.equals(password)){
                return id;
            }
        }
   return "-1";
    }

    public int connect_day(String id){
        Cursor cursor=mRDB.query("storage",null,null,null,null,null,null);
        int from=0,after=0,connect=0,longest=0;

        while(cursor.moveToNext()){
            if(id.equals(cursor.getString(5))) {

                after=cursor.getInt(0);
                if (after -1== from) connect = connect + 1;
                if (after -1!= from) {
                    if (connect >= longest) {
                        longest = connect;
                    }
                    connect = 0;
                }
                from=cursor.getInt(0);
            }
        }

        connect=(longest*100)+connect;
        return connect;
    }

    public int  judge_daka(String id,int day) {
        Cursor cursor = mRDB.query("storage", null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String sqlid = cursor.getString(5);
            int sqlday = cursor.getInt(0);
            if(sqlid.equals(id)&&sqlday==day)return 0;
        }
        return 1;
    }

    public int root_liulan(){
        int i=0;
        Cursor cursor=mRDB.query("storage",null,null,null,null,null,null);
        while(cursor.moveToNext()){
            liulan[i][0]=new String();
            liulan[i][1]=new String();
            liulan[i][2]=new String();

             liulan2[i]=cursor.getInt(0);
             liulan[i][0]=cursor.getString(1);
             liulan[i][1]=cursor.getString(2);
             liulan[i][2]=cursor.getString(5);
             i++;
        }

        judge=i;

        return judge;
    }

}
